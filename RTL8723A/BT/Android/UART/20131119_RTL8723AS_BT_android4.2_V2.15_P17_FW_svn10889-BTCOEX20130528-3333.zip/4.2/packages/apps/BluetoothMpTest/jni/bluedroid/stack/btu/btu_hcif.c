/******************************************************************************
 *
 *  Copyright (C) 1999-2012 Broadcom Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  This file contains functions that interface with the HCI transport. On
 *  the receive side, it routes events to the appropriate handler, e.g.
 *  L2CAP, ScoMgr. On the transmit side, it manages the command
 *  transmission.
 *
 ******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "gki.h"
#include "bt_types.h"
#include "hcimsgs.h"
#include "btu.h"
#include <utils/Log.h>



//Counter to track number of HCI command timeout
static int num_hci_cmds_timed_out;


/*******************************************************************************
**
** Function         btu_hcif_store_cmd
**
** Description      This function stores a copy of an outgoing command and
**                  and sets a timer waiting for a event in response to the
**                  command.
**
** Returns          void
**
*******************************************************************************/
static void btu_hcif_store_cmd (UINT8 controller_id, BT_HDR *p_buf)
{
    tHCI_CMD_CB * p_hci_cmd_cb = &(btu_cb.hci_cmd_cb[controller_id]);
    UINT16  opcode;
    BT_HDR  *p_cmd;
    UINT8   *p = (UINT8 *)(p_buf + 1) + p_buf->offset;

    /* get command opcode */
    STREAM_TO_UINT16 (opcode, p);

    /* don't do anything for certain commands */
    if ((opcode == HCI_RESET) || (opcode == HCI_HOST_NUM_PACKETS_DONE))
    {
        return;
    }

    /* allocate buffer (HCI_GET_CMD_BUF will either get a buffer from HCI_CMD_POOL or from 'best-fit' pool) */
    if ((p_cmd = HCI_GET_CMD_BUF(p_buf->len + p_buf->offset - HCIC_PREAMBLE_SIZE)) == NULL)
    {
        return;
    }

    /* copy buffer */
    memcpy (p_cmd, p_buf, sizeof(BT_HDR));

    /* If vendor specific save the callback function */
    if ((opcode & HCI_GRP_VENDOR_SPECIFIC) == HCI_GRP_VENDOR_SPECIFIC
#if BLE_INCLUDED == TRUE
        || (opcode == HCI_BLE_RAND )
        || (opcode == HCI_BLE_ENCRYPT)
#endif
       )
    {
#if 0
        BT_TRACE_2 (TRACE_LAYER_HCI, TRACE_TYPE_DEBUG,
                    "Storing VSC callback opcode=0x%04x, Callback function=0x%07x",
                    opcode, *(UINT32 *)(p_buf + 1));
#endif
        memcpy ((UINT8 *)(p_cmd + 1), (UINT8 *)(p_buf + 1), sizeof(void *));
    }

    memcpy ((UINT8 *)(p_cmd + 1) + p_cmd->offset,
            (UINT8 *)(p_buf + 1) + p_buf->offset, p_buf->len);

    /* queue copy of cmd */
    GKI_enqueue(&(p_hci_cmd_cb->cmd_cmpl_q), p_cmd);

    /* start timer */
    if (BTU_CMD_CMPL_TIMEOUT > 0)
    {
#if (defined(BTU_CMD_CMPL_TOUT_DOUBLE_CHECK) && BTU_CMD_CMPL_TOUT_DOUBLE_CHECK == TRUE)
        p_hci_cmd_cb->checked_hcisu = FALSE;
#endif
        btu_start_timer (&(p_hci_cmd_cb->cmd_cmpl_timer),
                         (UINT16)(BTU_TTYPE_BTU_CMD_CMPL + controller_id),
                         BTU_CMD_CMPL_TIMEOUT);
    }
}

static void send_recv_evt_message(short evt, UINT8 evt_opcode, UINT8 *p, UINT16 evt_len) 
{
	BT_HDR *p_msg;
	UINT8 *pp;

	if ((p_msg = (BT_HDR *)GKI_getbuf(BT_HDR_SIZE + evt_len + sizeof(UINT8) + sizeof(UINT8))) != NULL)
      {
                p_msg->event = evt;
		   p_msg->offset = 0;
		   pp = (UINT8 *)(p_msg + 1);
		   UINT8_TO_STREAM (pp, evt_opcode);
		   UINT8_TO_STREAM (pp, evt_len);
		   if(evt_len > 0)
		   	ARRAY_TO_STREAM(pp, p, evt_len);
		   
                GKI_send_msg (BTIF_TASK, BTU_BTIF_MBOX, p_msg);
        }
}



/*******************************************************************************
**
** Function         btu_hcif_process_event
**
** Description      This function is called when an event is received from
**                  the Host Controller.
**
** Returns          void
**
*******************************************************************************/
void btu_hcif_process_event (UINT8 controller_id, BT_HDR *p_msg)
{
    UINT8   *p = (UINT8 *)(p_msg + 1) + p_msg->offset;
    UINT8   hci_evt_code, hci_evt_len;

    STREAM_TO_UINT8  (hci_evt_code, p);
    STREAM_TO_UINT8  (hci_evt_len, p);


    send_recv_evt_message(BT_EVT_MP_TEST_EVT, hci_evt_code, p, hci_evt_len);

    num_hci_cmds_timed_out = 0;
}


/*******************************************************************************
**
** Function         btu_hcif_send_cmd
**
** Description      This function is called to check if it can send commands
**                  to the Host Controller. It may be passed the address of
**                  a packet to send.
**
** Returns          void
**
*******************************************************************************/
void btu_hcif_send_cmd (UINT8 controller_id, BT_HDR *p_buf)
{
    tHCI_CMD_CB * p_hci_cmd_cb = &(btu_cb.hci_cmd_cb[controller_id]);

#if ((L2CAP_HOST_FLOW_CTRL == TRUE)||defined(HCI_TESTER))
    UINT8 *pp;
    UINT16 code;
#endif
            	  ALOGE("btu_hcif_send_cmd++");
    /* If there are already commands in the queue, then enqueue this command */
    if ((p_buf) && (p_hci_cmd_cb->cmd_xmit_q.count))
    {
        GKI_enqueue (&(p_hci_cmd_cb->cmd_xmit_q), p_buf);
        p_buf = NULL;
    }
	
   if ((controller_id == LOCAL_BR_EDR_CONTROLLER_ID)
         && (p_hci_cmd_cb->cmd_window == 0))        
    {
        p_hci_cmd_cb->cmd_window = p_hci_cmd_cb->cmd_xmit_q.count + 1;
    }

    /* See if we can send anything */
    while (p_hci_cmd_cb->cmd_window != 0)
    {
        if (!p_buf)
            p_buf = (BT_HDR *)GKI_dequeue (&(p_hci_cmd_cb->cmd_xmit_q));

        if (p_buf)
        {
            btu_hcif_store_cmd(controller_id, p_buf);

#if ((L2CAP_HOST_FLOW_CTRL == TRUE)||defined(HCI_TESTER))
            pp = (UINT8 *)(p_buf + 1) + p_buf->offset;

            STREAM_TO_UINT16 (code, pp);

            /*
             * We do not need to decrease window for host flow control,
             * host flow control does not receive an event back from controller
             */
            if (code != HCI_HOST_NUM_PACKETS_DONE)
#endif
                p_hci_cmd_cb->cmd_window--;

            if (controller_id == LOCAL_BR_EDR_CONTROLLER_ID)
            {
            	  ALOGE("HCI_CMD_TO_LOWER");
                HCI_CMD_TO_LOWER(p_buf);
            }
            else
            {
                /* Unknown controller */
                BT_TRACE_1 (TRACE_LAYER_HCI, TRACE_TYPE_WARNING, "BTU HCI(ctrl id=%d) controller ID not recognized", controller_id);
                GKI_freebuf(p_buf);;
            }

            p_buf = NULL;
        }
        else
            break;
    }
            	  ALOGE("btu_hcif_send_cmd--");
    if (p_buf)
        GKI_enqueue (&(p_hci_cmd_cb->cmd_xmit_q), p_buf);


}

/******************************************************************************
*
**
** Function         btu_hcif_cmd_timeout
**
** Description      Handle a command timeout
**
** Returns          void
**
*******************************************************************************/
void btu_hcif_cmd_timeout (UINT8 controller_id)
{

}

