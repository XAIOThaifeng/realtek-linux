#if defined(CONFIG_BT_RTKBTRFKILL)
struct rtkbt_platform_data {
	const char *name;
	int (*bt_wake_ap)(void);
	void (*ap_wake_bt)(int value);
	int (*poweron)(void);
	int (*poweroff)(void);
};
#endif
