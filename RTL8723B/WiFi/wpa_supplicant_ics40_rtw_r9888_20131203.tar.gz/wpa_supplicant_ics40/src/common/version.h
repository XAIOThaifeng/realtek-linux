#ifndef VERSION_H
#define VERSION_H

#ifndef VERSION_STR_POSTFIX
#define VERSION_STR_POSTFIX ""
#endif /* VERSION_STR_POSTFIX */

#define VERSION_STR "0.8.x" VERSION_STR_POSTFIX


#include "rtw_version.h"
#ifdef RTW_VERSION
	#undef VERSION_STR
	#define VERSION_STR "2.0-devel" VERSION_STR_POSTFIX "_" RTW_VERSION
#endif








#endif /* VERSION_H */
