#!/bin/sh

modprobe cfg80211
insmod 8723be.ko rtw_mp_mode=1


#Enable Device for MP operation
ifconfig wlan1 up


#enter MP mode
iwpriv wlan1 mp_start


#Switch Antenna to WiFi (For Combo IC)
iwpriv wlan1 mp_setrfpath 1


# set channel to 1 . 2, 3, 4~13 etc.
iwpriv wlan1 mp_channel 1


iwpriv wlan1 mp_bandwidth 40M=0,shortGI=0 
#set 20M mode and long GI,set 40M
#is 40M=1 , set 80M= 2.


#Select Antenna A for operation,if
#device have 2x2 antennam select antenna "a" or "b" and "ab" for operation.
#set OFDM data rate to 54Mbps, ex:
#CCK 1M = 2, CCK 5.5M = 11 ;OFDM 6M=12、54M = 108; N Rate: MCS0 = 128,MCS1 =
iwpriv wlan1 mp_ant_tx a


#129,MCS 2=130....MCS15 = 143 etc ;VHT Rate :MCS0 = 144,
#MCS 1=145,MCS 2=146 ~     MCS9 =153.
iwpriv wlan1 mp_rate 108


#If you want to get and use Efuse Tx power index,please input advance the command
#"iwpriv wlan0 mp_get_txpower ",and use the return value fill to following orange
#field.


#set path A and path B Tx power
#level,the Range is 0~63.
iwpriv wlan1 mp_txpower patha=44,pathb=44



iwpriv wlan1 mp_ctx background,pkt #start continuous Tx
#iwpriv wlan0 mp_ctx stop #stop continuous Tx
#If you want to change the input parameter(rate、channel、txpower、
#bandwidth),please must input advance the command "iwpriv wlan0 mp_ctx stop".
#iwpriv wlan0 mp_stop
# exit MP mode
#If you want to continue MP test , don’t do this command.
#ifconfig wlan0 down
# close WLAN interface
