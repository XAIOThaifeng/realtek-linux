#!/bin/sh

rmmod 8723be
modprobe -r cfg80211


