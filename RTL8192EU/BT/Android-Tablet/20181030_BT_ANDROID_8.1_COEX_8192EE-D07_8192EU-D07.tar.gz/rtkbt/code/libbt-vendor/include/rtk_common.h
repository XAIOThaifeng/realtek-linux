
#ifndef RTK_COMMON_H
#define RTK_COMMON_H

#define RTK_UNUSED(x) (void)(x)
#endif
