#include "rtkbt_api_ver_toolchain.h"

#define SUBVER_RTKBT_API    (1)
#define SUBVER_RTKBT_REVISION     (2)
#define SUBVER_RTKBT_CUSTOMIZED_REVISION (0)

