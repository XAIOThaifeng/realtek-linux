release_package()
{
	# This function expect two global variables:
	# $RELEASE_FOLDER is the folder name for new release
	# $RELEASE_TYPE_NAME is the release type name, indicate the folder in releases/
	
	#### COMMON ####
	mkdir -p $RELEASE_FOLDER/android_ref_codes_JB_4.2
	cp -rf common/android_ref_codes_JB_4.2/* $RELEASE_FOLDER/android_ref_codes_JB_4.2/.
	
	mkdir -p $RELEASE_FOLDER/android_ref_codes_KK_4.4
	cp -rf common/android_ref_codes_KK_4.4/* $RELEASE_FOLDER/android_ref_codes_KK_4.4/.

	mkdir -p $RELEASE_FOLDER/android_ref_codes_L_5.x
	cp -rf common/android_ref_codes_L_5.x/* $RELEASE_FOLDER/android_ref_codes_L_5.x/.

	mkdir -p $RELEASE_FOLDER/android_ref_codes_M_6.x
	cp -rf common/android_ref_codes_M_6.x/* $RELEASE_FOLDER/android_ref_codes_M_6.x/.

	mkdir -p $RELEASE_FOLDER/document
	cp -rf common/document/* $RELEASE_FOLDER/document/.
	rm -rf $RELEASE_FOLDER/document/HowTo_debug_BT_coexistence.doc
	rm -rf $RELEASE_FOLDER/document/RTL8192D_operation_mode.doc
	rm -rf $RELEASE_FOLDER/document/HowTo_port_wireless_driver_to_Google_ChromiumOS.doc
	
	mkdir -p $RELEASE_FOLDER/WiFi_Direct_User_Interface
	cp -rf common/WiFi_Direct_User_Interface/* $RELEASE_FOLDER/WiFi_Direct_User_Interface/.
	
	mkdir -p $RELEASE_FOLDER/wireless_tools
	cp -rf common/wireless_tools/* $RELEASE_FOLDER/wireless_tools/.
	
	mkdir -p $RELEASE_FOLDER/wpa_supplicant_hostapd
	cp -rf common/wpa_supplicant_hostapd/* $RELEASE_FOLDER/wpa_supplicant_hostapd/.
	rm -rf $RELEASE_FOLDER/wpa_supplicant_hostapd/wpa_supplicant-0.6.9_wps_patch_20100201_1.zip
	rm -rf $RELEASE_FOLDER/wpa_supplicant_hostapd/wpa_0_6_9.conf
	rm -rf $RELEASE_FOLDER/wpa_supplicant_hostapd/wpa_supplicant_8_jb_4.1_rtw_r7473.20130517.tar.gz
	rm -rf $RELEASE_FOLDER/wpa_supplicant_hostapd/wpa_supplicant_8_jb_4.3_rtw_r9301.20131011.tar.gz

	mkdir -p $RELEASE_FOLDER/mp_tools
	cp -rf common/mp_tools/* $RELEASE_FOLDER/mp_tools/.

	cp -rf common/install.sh $RELEASE_FOLDER/.
	
	
	#### RELEASES ####
	mkdir -p $RELEASE_FOLDER/driver
	cp -rf releases/$RELEASE_TYPE_NAME/driver/* $RELEASE_FOLDER/driver/.
	
	cp -rf releases/$RELEASE_TYPE_NAME/readme.txt $RELEASE_FOLDER/.
	cp -rf releases/$RELEASE_TYPE_NAME/ReleaseNotes.doc $RELEASE_FOLDER/.
}